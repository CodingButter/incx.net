# Configuration System Documentation

This directory contains all configuration files for the INCX website template. The configuration system allows you to update content, settings, and data without modifying HTML files directly.

## Directory Structure

```
config/
├── global.json           # Global settings used across all pages
├── products.json         # Product catalog for all services
├── testimonials.json     # Customer testimonials
├── pages/                # Page-specific configurations
│   ├── home.json
│   ├── about.json
│   ├── contact.json
│   ├── dedicated-servers.json
│   ├── vps.json
│   ├── colocation.json
│   ├── network.json
│   └── testimonials.json
└── archive/              # Deprecated config files (for reference only)
```

## How the Configuration System Works

1. **Loading Process**: When a page loads, `config-loader.js` automatically loads:
   - `global.json` - Always loaded on every page
   - The specific page config from `pages/` directory (if it exists)
   - Additional configs as needed (products.json, testimonials.json)

2. **Template Variables**: You can use template variables in any config file:
   - Format: `{{path.to.value}}`
   - Example: `{{company.name}}` will be replaced with the company name from global.json
   - Works in any string value in page configs

3. **Dynamic Content**: JavaScript automatically updates page content from configs:
   - Hero sections (titles, subtitles, images)
   - Stats and features
   - Product listings
   - Testimonials
   - Meta tags for SEO

## Configuration Files

### 1. global.json
Contains site-wide settings and data used across all pages.

```json
{
  "company": {
    "name": "Interconnecx LLC",
    "shortName": "INCX",
    "founded": "2009",
    "phone": "810-202-7474",
    "email": "support@incx.net"
  },
  "features": {
    "support": {
      "availability": "24/7/365",
      "responseTime": "< 15 minutes"
    },
    "network": {
      "uptime": "99.99%",
      "ddosProtection": "500Gbps"
    }
  },
  "network": {
    "bandwidth": "100Gbps",
    "uptime": "99.99%"
  },
  "datacenters": [
    {
      "id": "dtw",
      "city": "Detroit",
      "state": "Michigan",
      "stateCode": "MI",
      "tier": 3
    }
  ]
}
```

**Key Sections to Update:**
- `company`: Business information
- `features`: Key selling points and features
- `network`: Network specifications
- `datacenters`: List of datacenter locations (automatically displayed on home page)
- `socials`: Social media links

### 2. products.json
Contains all product categories and their items.

```json
{
  "categories": {
    "dedicated-servers": {
      "name": "Dedicated Servers",
      "products": [
        {
          "id": "dell-r440",
          "name": "Dell PowerEdge R440",
          "price": 149,
          "specs": {
            "cpu": "2x Intel Xeon Silver 4214",
            "cores": "24 Cores / 48 Threads",
            "ram": "64GB DDR4 ECC",
            "storage": "2x 1TB NVMe SSD"
          },
          "features": ["Full Root Access", "100TB Bandwidth"],
          "badge": "Most Popular",
          "badgeColor": "primary",
          "featured": true
        }
      ]
    }
  }
}
```

**How to Add/Update Products:**
1. Find the appropriate category (`dedicated-servers`, `vps`, `colocation`)
2. Add/edit products in the `products` array
3. Set `featured: true` for products to show on home page
4. Add `badge` and `badgeColor` for special labels

**Badge Colors:**
- `primary` - Blue
- `secondary` - Gray
- `success` - Green
- `warning` - Yellow
- `danger` - Red

### 3. testimonials.json
Contains customer testimonials and reviews.

```json
{
  "testimonials": [
    {
      "id": "test-001",
      "name": "John Doe",
      "company": "Tech Corp",
      "rating": 5,
      "service": "Dedicated Servers",
      "featured": true,
      "verified": true,
      "title": "Excellent Service",
      "content": "Great hosting experience..."
    }
  ]
}
```

**Managing Testimonials:**
- Set `featured: true` to show on home page (max 3)
- `verified: true` adds a verified badge
- `rating` should be 1-5
- `service` should match product categories

### 4. Page Configurations (pages/*.json)

Each page can have its own configuration file with:

```json
{
  "meta": {
    "title": "Page Title - Interconnecx",
    "description": "SEO description",
    "keywords": "keyword1, keyword2"
  },
  "hero": {
    "title": "Hero Title",
    "subtitle": "Hero subtitle with {{template.variables}}",
    "image": "/images/hero-image.jpg",
    "price": "Starting at $49/mo"
  },
  "features": [
    "Feature 1",
    "Feature 2"
  ],
  "stats": {
    "enabled": true,
    "items": [
      {
        "label": "Customers",
        "value": "2,500+",
        "icon": "fas fa-users"
      }
    ]
  }
}
```

**Page-Specific Features:**
- `meta`: SEO metadata
- `hero`: Hero section content
- `features`: Feature highlights (varies by page)
- `stats`: Statistical displays with icons

## How to Update Content

### Quick Updates

1. **Change Company Info:**
   - Edit `global.json` → `company` section
   - Changes appear site-wide

2. **Update Product Prices:**
   - Edit `products.json` → find product → change `price`
   - Refresh page to see changes

3. **Add New Testimonial:**
   - Edit `testimonials.json` → add new object to `testimonials` array
   - Set `featured: true` for home page display

4. **Change Hero Text:**
   - Edit `pages/[pagename].json` → `hero` section
   - Update `title` and `subtitle`

5. **Update Datacenter Locations:**
   - Edit `global.json` → `datacenters` array
   - Add/remove datacenter objects
   - Home page automatically updates

### Template Variables Reference

Common variables you can use in page configs:

```
{{company.name}}                    - Company full name
{{company.shortName}}               - Company short name (INCX)
{{company.founded}}                 - Year founded
{{company.phone}}                   - Phone number
{{company.email}}                   - Email address

{{network.bandwidth}}               - Network bandwidth (100Gbps)
{{network.uptime}}                  - Uptime guarantee (99.99%)
{{network.ddosProtection}}          - DDoS protection level

{{features.support.availability}}   - Support availability (24/7/365)
{{features.support.responseTime}}   - Support response time
{{features.billing.setupFee}}       - Setup fee information
{{features.guarantees.uptime}}      - Uptime guarantee

{{datacenters.length}}              - Number of datacenters (auto-calculated)
{{datacenters.count}}               - Same as above
```

### Advanced Updates

1. **Using Template Variables:**
```json
{
  "subtitle": "Serving businesses since {{company.founded}} with {{network.bandwidth}} network"
}
```

2. **Adding New Datacenter:**
```json
{
  "id": "chi",
  "city": "Chicago",
  "state": "Illinois",
  "stateCode": "IL",
  "tier": 3,
  "available": true
}
```

3. **Creating Product with Badge:**
```json
{
  "id": "product-id",
  "name": "Product Name",
  "price": 99,
  "badge": "Limited Offer",
  "badgeColor": "danger",
  "featured": true,
  "specs": {...}
}
```

## Important Notes

1. **JSON Syntax**: Ensure valid JSON syntax (use jsonlint.com to validate)
2. **Image Paths**: Use absolute paths starting with `/images/`
3. **Cache Busting**: Clear browser cache (Ctrl+Shift+R) after updates
4. **Template Variables**: Only work in page configs, not in global.json
5. **Loading Order**: Global config loads first, then page-specific
6. **File Names**: Page config names must match HTML file names

## Troubleshooting

### Content Not Updating:
- Clear browser cache (Ctrl+Shift+R)
- Check browser console for errors (F12)
- Validate JSON syntax at jsonlint.com
- Ensure config file name matches page name

### Images Not Loading:
- Verify image exists in `/images/` folder
- Check path starts with `/images/`
- Ensure filename matches exactly (case-sensitive)
- Check image file extension (.jpg, .png, etc.)

### Template Variables Not Working:
- Verify path exists in global.json
- Check for typos in variable name
- Ensure using double curly braces `{{}}`
- Variables only work in page configs, not global

### Products Not Showing:
- Set `featured: true` for home page display
- Check category name matches exactly
- Verify product has all required fields
- Ensure products.json is valid JSON

### Testimonials Not Appearing:
- Set `featured: true` for homepage (max 3)
- Check testimonials.json is valid
- Verify `service` field matches product categories
- Ensure rating is between 1-5

## Best Practices

1. **Backup Before Changes**: Keep copies of working configs
2. **Test Locally**: Test changes in development first
3. **Incremental Updates**: Make small changes and test
4. **Consistent Naming**: Use consistent IDs and naming
5. **SEO Optimization**: Always update meta tags for new pages
6. **Use Templates**: Use template variables for repeated content
7. **Validate JSON**: Always validate JSON before saving
8. **Document Changes**: Keep notes of significant changes

## Examples

### Example: Update Network Speed from 100Gbps to 200Gbps
1. Open `global.json`
2. Find `"network": { "bandwidth": "100Gbps"`
3. Change to `"bandwidth": "200Gbps"`
4. Save file
5. Clear browser cache and refresh

### Example: Add New Product
1. Open `products.json`
2. Find appropriate category
3. Add to products array:
```json
{
  "id": "new-server",
  "name": "New Server Model",
  "price": 199,
  "featured": true,
  "badge": "New",
  "badgeColor": "success",
  "specs": {
    "cpu": "Intel Xeon Gold",
    "ram": "128GB DDR4",
    "storage": "4x 2TB NVMe"
  },
  "features": ["Full Root Access", "Unlimited Bandwidth"]
}
```

### Example: Update Hero Title
1. Open `pages/home.json`
2. Find `"hero": { "headline":`
3. Update text
4. Can use variables: `"headline": "Premium Hosting with {{network.bandwidth}} Network"`

## Support

For issues or questions about the configuration system:
- Check browser console for error messages
- Validate JSON at jsonlint.com
- Review this documentation
- Archive old configs before major changes

---

Last Updated: November 2024
Version: 2.0